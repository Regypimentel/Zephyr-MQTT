# Braço Robótico MQTT - ESP32 Zephyr

### Compilação e Flash
```bash
west build -b esp32_devkitc_wrover
west flash
